package com.cg.university.dto;

public class User {
	private String login_id;
	private String password;
	private String role;
	public User(String login_id, String password, String role) {
		super();
		this.login_id = login_id;
		this.password = password;
		this.role = role;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "User [login_id=" + login_id + ", password=" + password
				+ ", role=" + role + "]";
	}
	
	public String getLogin_id() {
		return login_id;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getRole() {
		return role;
	}
	
	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setRole(String role) {
		this.role = role;
	}
	

}
