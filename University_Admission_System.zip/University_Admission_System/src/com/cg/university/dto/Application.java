package com.cg.university.dto;

import java.util.Date;

public class Application {
	private long Application_id;
	private String full_name;
	private Date date_of_birth;
	private String highest_qualification;
	private int marks_obtained;
	private String email_id;
	private Date Date_Of_Interview;
	public Application(long application_id, String full_name,
			Date date_of_birth, String highest_qualification,
			int marks_obtained, String email_id, Date date_Of_Interview) {
		super();
		Application_id = application_id;
		this.full_name = full_name;
		this.date_of_birth = date_of_birth;
		this.highest_qualification = highest_qualification;
		this.marks_obtained = marks_obtained;
		this.email_id = email_id;
		Date_Of_Interview = date_Of_Interview;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Application [Application_id=" + Application_id + ", full_name="
				+ full_name + ", date_of_birth=" + date_of_birth
				+ ", highest_qualification=" + highest_qualification
				+ ", marks_obtained=" + marks_obtained + ", email_id="
				+ email_id + ", Date_Of_Interview=" + Date_Of_Interview + "]";
	}
	
	public long getApplication_id() {
		return Application_id;
	}
	
	public String getFull_name() {
		return full_name;
	}
	
	public Date getDate_of_birth() {
		return date_of_birth;
	}
	
	public String getHighest_qualification() {
		return highest_qualification;
	}
	
	public int getMarks_obtained() {
		return marks_obtained;
	}
	
	public String getEmail_id() {
		return email_id;
	}
	
	public Date getDate_Of_Interview() {
		return Date_Of_Interview;
	}
	
	public void setApplication_id(long application_id) {
		Application_id = application_id;
	}
	
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	
	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	
	public void setHighest_qualification(String highest_qualification) {
		this.highest_qualification = highest_qualification;
	}
	
	public void setMarks_obtained(int marks_obtained) {
		this.marks_obtained = marks_obtained;
	}
	
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	
	public void setDate_Of_Interview(Date date_Of_Interview) {
		Date_Of_Interview = date_Of_Interview;
	}
	
	

}
