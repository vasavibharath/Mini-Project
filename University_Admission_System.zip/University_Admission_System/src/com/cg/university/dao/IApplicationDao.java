package com.cg.university.dao;

public interface IApplicationDao {

}
