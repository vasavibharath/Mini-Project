package com.cg.university.dao;

public class ApplicationDaoImpl {

}
