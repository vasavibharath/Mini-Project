package com.cg.university.exception;

public class ApplicationException {

}
