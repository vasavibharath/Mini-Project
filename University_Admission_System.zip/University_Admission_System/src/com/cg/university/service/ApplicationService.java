package com.cg.university.service;

public interface ApplicationService {

}
