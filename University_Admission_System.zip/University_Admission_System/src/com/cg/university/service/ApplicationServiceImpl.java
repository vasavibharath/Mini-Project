package com.cg.university.service;

public class ApplicationServiceImpl {

}
