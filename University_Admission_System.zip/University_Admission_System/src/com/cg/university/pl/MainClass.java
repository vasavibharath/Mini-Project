package com.cg.university.pl;

public class MainClass {

}
