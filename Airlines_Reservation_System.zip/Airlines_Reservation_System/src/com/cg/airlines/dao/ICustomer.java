package com.cg.airlines.dao;

import java.util.ArrayList;

import com.cg.airlines.dto.Customer;
import com.cg.airlines.dto.User;
import com.cg.airlines.exception.CustomerException;

public interface ICustomer {
	User CheckUser(String userName, String password);
	int registerCustomer(Customer cust)throws CustomerException;
	Customer removeCustomer(int custId) throws CustomerException;
	Customer getCustomerById(int custId) throws CustomerException;
	ArrayList<Customer>getAllCustomer()throws CustomerException;

}
