package com.cg.airlines.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.airlines.dao.CustomerDaoImpl;
import com.cg.airlines.dao.ICustomer;
import com.cg.airlines.dto.Customer;
import com.cg.airlines.dto.User;
import com.cg.airlines.exception.CustomerException;


public class CustomerServiceImpl implements ICustomerService{
	ICustomer dao;
	
	public void setDao(ICustomer dao)// set class
	{
		this.dao=dao;
	}
	public CustomerServiceImpl()
	{
		dao = new CustomerDaoImpl();
	}
	@Override
	public int registerCustomer(Customer cust) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.registerCustomer(cust);
	}
	public boolean validateEmail(String custEmail) {
		// TODO Auto-generated method stub
		String pattern="^[A-Za-z0-9+_.-]+@(.+)$";
		if(Pattern.matches( pattern,custEmail))
		{
			return true;
		}
		else
			return false;
	}
	
	@Override
	public Customer removeCustomer(int custId) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.removeCustomer(custId);
	}
	@Override
	public Customer getCustomerById(int custId) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.getCustomerById(custId);
	}
	@Override
	public ArrayList<Customer> getAllCustomer() throws CustomerException {
		// TODO Auto-generated method stub
		return dao.getAllCustomer();
	}
	@Override
	public User CheckUser(String username, String password) {
		// TODO Auto-generated method stub
		return dao.CheckUser(username, password);
	}
	
	
	
}
